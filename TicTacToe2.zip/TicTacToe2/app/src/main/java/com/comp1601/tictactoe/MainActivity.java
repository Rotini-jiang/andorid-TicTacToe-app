package com.comp1601.tictactoe;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    Button cells[];
    TextView status;
    int[] matrix;

    private int[][] triads = {{0,1,2},{3,4,5},{6,7,8},{0,3,6},{1,4,7},{2,5,8},{0,4,8},{2,4,6}};
    private int[][] triadsOfCell = {{0,3,6},{0,4},{0,5,7},{1,3},{1,4,6,7},{1,5},{2,3,7},{2,4},{2,5,6}};
    int[] scoreTriad;
    int[] scoreCell;
    boolean isRunning=false;
    private Button playerSc1;
    private Button playerSc2;

    int X = 1;
    int O = 0;
    int UNMARKED = -1;
    int cellsNum = 9;
    int triadsNum = 8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        status = (TextView) findViewById(R.id.status);
        cells = new Button[cellsNum];
        cells[0] = (Button) findViewById(R.id.button_00);
        cells[1] = (Button) findViewById(R.id.button_01);
        cells[2] = (Button) findViewById(R.id.button_02);
        cells[3] = (Button) findViewById(R.id.button_03);
        cells[4] = (Button) findViewById(R.id.button_04);
        cells[5] = (Button) findViewById(R.id.button_05);
        cells[6] = (Button) findViewById(R.id.button_06);
        cells[7] = (Button) findViewById(R.id.button_07);
        cells[8] = (Button) findViewById(R.id.button_08);
        findViewById(R.id.reset_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reset();
            }
        });
        reset();
        playerSc1 = findViewById(R.id.player1_sc);
        playerSc2 = findViewById(R.id.player2_sc);
    }


    public void hit(View v){

        int index = Integer.parseInt(v.getTag().toString());
        if(isRunning && matrix[index]==UNMARKED){
            cells[index].setText("X");
            matrix[index] = X;
            checkStatus();
            if(isRunning){
                Comp();
                checkStatus();
            }
        }
    }

    public void Comp(){
        int index=getFavourableCell();
        cells[index].setText("O");
        matrix[index] = O;
    }

    public int getFavourableCell(){
        scoreTriad();
        scoreCell();
        int maxi=0;
        for(int i=0;i<cellsNum;i++){
            if(scoreCell[maxi]<scoreCell[i])
                maxi  = i;
        }
        return maxi;
    }

    public void scoreTriad(){
        for(int i=0;i<triadsNum;i++){
            int score=0;
            int nX = getNX(i);
            int nO = getNO(i);
            if(nO==2 && nX==0) score=6;
            if(nO==0 && nX==2) score=5;
            if(nO==1 && nX==0) score=2;
            if(nO==0 && nX==1) score=2;
            if(nO==0 && nX==0) score=1;
            scoreTriad[i]=score;
        }
    }

    public void scoreCell(){

        for(int i=0;i<cellsNum;i++){
            int score = -1;
            if(matrix[i] == UNMARKED){
                score = 0;
                for(int j:triadsOfCell[i]){
                    score += scoreTriad[j];
                }
            }
            scoreCell[i] = score;
        }
    }

    public int getNX(int i){
        int nX = 0;
        for(int j:triads[i]){
            if(matrix[j]==X) nX++;
        }
        return nX;
    }

    public int getNO(int i){
        int nO = 0;
        for(int j:triads[i]){
            if(matrix[j]==O) nO++;
        }
        return nO;
    }

    public void checkStatus(){
        for(int i=0;i<triadsNum;i++){
            int nX=getNX(i);
            int nO=getNO(i);
            String j = new String();
            j = j + 1;
            if(nX==3){
                status.setText("You Win!!!");
                playerSc1.setText(j);
                isRunning=false;
                cells[2].setBackgroundColor(Color.RED);
                cells[4].setBackgroundColor(Color.RED);
                cells[6].setBackgroundColor(Color.RED);
                return;
            }
            else if(nO==3){
                status.setText("You Lose!!!");
                isRunning=false;
                playerSc2.setText(j);
                cells[2].setBackgroundColor(Color.RED);
                cells[4].setBackgroundColor(Color.RED);
                cells[6].setBackgroundColor(Color.RED);
                return;
            }
        }
        for(int i=0;i<cellsNum;i++){
            if(matrix[i]==UNMARKED){
                break;
            }
            if(i==8){
                status.setText("Draw!!!");
                isRunning=false;
            }
        }
    }

    public void reset(){
        matrix=new int[cellsNum];
        Arrays.fill(matrix, UNMARKED);
        for(Button b:cells){
            b.setText(" ");
        }
        status.setText("");
        scoreTriad=new int[triadsNum];
        scoreCell=new int[cellsNum];
        isRunning=true;
        cells[2].setBackgroundColor(Color.rgb(214,215,215));
        cells[4].setBackgroundColor(Color.rgb(214,215,215));
        cells[6].setBackgroundColor(Color.rgb(214,215,215));
    }

}
